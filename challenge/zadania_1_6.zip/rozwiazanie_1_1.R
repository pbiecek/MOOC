dat <- read.table("http://biecek.pl/R/dane/daneO.csv", sep=";")
srWiek <- mean(dat$Wiek)
